#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>


void get_addr_info(const char* address, const char* port, struct addrinfo** res){
  int status;
  struct addrinfo hints, p;

  memset(&hints,0,sizeof(hints));

  hints.ai_family=AF_INET;
  hints.ai_socktype=SOCK_STREAM;
  hints.ai_protocol=0;

  status = getaddrinfo(address,port,&hints,res);
  if (status == -1) {
    exit(EXIT_FAILURE);
  }
}



int do_socket(int domain, int type, int protocol) {
  int sockfd;
  int yes = 1;
  sockfd = socket(domain,type,protocol);
  if (sockfd == -1)
  {
    perror("socket");
    exit(EXIT_FAILURE);


  }
  else
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1){
        error("ERROR setting socket options");
      }
    return sockfd;
  }



void do_connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen) {

    int res = connect(sockfd, addr, addrlen);

    if (res != 0) {
      perror("connect");
      exit(EXIT_FAILURE);
    }

}

void readline(int fd, void *str, size_t maxlen){
  int msg = 0;
  printf("Veuillez entrer un message à envoyer\n");
  fgets(str, maxlen, stdin);
  do{
    msg += read(fd, str+msg, maxlen-msg);
  } while(msg!= maxlen);
}


void handle_client_message(int fd, const void *str, size_t maxlen){
  int sockWrite = 0;
  do{
    sockWrite += write(fd, str+sockWrite, maxlen-sockWrite);
  } while(sockWrite != maxlen);
}

int main(int argc,char** argv)
{


    if (argc != 3)
    {
        fprintf(stderr,"usage: RE216_CLIENT hostname port\n");
        return 1;
    }
    struct addrinfo** res;
    //get address info from the server
    get_addr_info(argv[1], argv[2], res);

    //get the socket
    int sockfd = do_socket(AF_INET,SOCK_STREAM,0);

    //connect to remote socket
    do_connect(sockfd,(*res)->ai_addr,(*res)->ai_addrlen);

    //get user input
    char *str=malloc(10);

    readline(sockfd,str,100);

    //send message to the server
    handle_client_message(sockfd,str,100);

    return 0;
}
